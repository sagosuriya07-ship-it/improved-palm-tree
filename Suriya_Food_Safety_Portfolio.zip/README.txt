# A. Suriya – Food Safety & Quality Portfolio

This is a static portfolio website designed in the style of the supplied reference portfolio, with your own professional information and training photo.

## Files
- `index.html` – website content
- `style.css` – responsive design
- `script.js` – mobile menu and year
- `assets/food-safety-training.jpg` – supplied training/briefing photo

## Publish as your own link with GitHub Pages
1. Create a new GitHub repository, for example `suriya-portfolio`.
2. Upload all files and the `assets` folder.
3. In GitHub: **Settings → Pages → Deploy from a branch → main → /(root) → Save**.
4. GitHub will provide your public portfolio link.

## Important content note
The professional experience dates and employers are kept from the supplied resume. The achievement section also includes the separate achievement figures you provided for India Sweet House (17 food safety audits, 132 internal audits, 60+ coverage/training, 100% complaint resolution, RCA/CAPA, pest-control monitoring and quality improvement).
